//
//  ViewController.swift
//  Basket
//
//  Created by Johanna Smith-Palliser on 1/19/17.
//  Copyright © 2017 Johanna Smith-Palliser. All rights reserved.
//

import UIKit

class LaunchScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nameLabel = UILabel(frame: CGRect(x: 150, y: 300, width: 250, height: 40))
        nameLabel.text = "Walmart"
        view.addSubview(nameLabel)
        
        let signInButton = UIButton(frame: CGRect(x: 100, y: 400, width: 150, height: 40))
        signInButton.center.x = view.center.x
        signInButton.setTitle("let's go", for: .normal)
        signInButton.backgroundColor = UIColor(red: 0, green: 101/255, blue: 188/255, alpha: 1.0)
        signInButton.setTitleColor(.white, for: .normal)
        signInButton.layer.cornerRadius = 8
        signInButton.addTarget(self, action: #selector(goToSignIn), for: .touchUpInside)
        view.addSubview(signInButton)
        
        view.backgroundColor = .white
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(false)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(false)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    func goToSignIn() {
        // Customize back button for LoginPageViewController
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "test", style: .plain, target: self, action: #selector(goToSignIn))
        navigationController?.pushViewController(LoginPageViewController(), animated: true)
    }
}

