//
//  LoginPageViewController.swift
//  Basket
//
//  Created by Johanna Smith-Palliser on 1/19/17.
//  Copyright © 2017 Johanna Smith-Palliser. All rights reserved.
//

import UIKit

let WBlue = UIColor(red: 0, green: 101/255, blue: 188/255, alpha: 1.0)

class LoginPageViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = WBlue
        title = "Log In"
        navigationController?.navigationBar.titleTextAttributes = [
            //NSFontAttributeName: UIFont(name: "SIGNIKA", size: 30)!,
            NSForegroundColorAttributeName: UIColor.white
        ]
        navigationController?.navigationBar.barStyle = UIBarStyle(rawValue: 2)!
        
        let FBSignInButton = UIButton(frame: CGRect(x: 100, y: 400, width: 150, height: 40))
        FBSignInButton.center.x = view.center.x
        FBSignInButton.setTitle("SIGN IN WITH FACEBOOK", for: .normal)
        FBSignInButton.backgroundColor = UIColor(red: 0, green: 101/255, blue: 188/255, alpha: 1.0)
        FBSignInButton.setTitleColor(.white, for: .normal)
        FBSignInButton.layer.cornerRadius = 8
        //signInButton.addTarget(self, action: #selector(go), for: .touchUpInside)
        view.addSubview(FBSignInButton)
        
        
    }
    
    
}
